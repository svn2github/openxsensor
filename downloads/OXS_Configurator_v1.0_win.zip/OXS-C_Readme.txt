Requirements:

You need to have java installed:
- Windows:
  Go to http://java.com/en/download/manual.jsp and look under Windows section.

- Debian, Ubuntu, etc.:
  On the command line, type:
  $ sudo apt-get install openjdk-7-jre
  The openjdk-7-jre package contains just the Java Runtime Environment.

- Fedora, Oracle Linux, Red Hat Enterprise Linux, etc.:
  On the command line, type:
  $ su -c "yum install java-1.7.0-openjdk"
  The java-1.7.0-openjdk package contains just the Java Runtime Environment.

- Mac OSX:
  Go to http://java.com/en/download/manual.jsp and look under Mac OSX section.

Installation:
Put the folder anywhere you want on your computer.
You can set a shortcut if you wish.

Usage:
Double-click "OXS_Configurator.exe" on windows 
                     "OXS_Configurator" on linux
                     "OXS_Configurator.app" on mac
